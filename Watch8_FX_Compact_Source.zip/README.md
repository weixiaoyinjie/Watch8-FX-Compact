# Galaxy Watch8 · 汇率通紧凑版（源码）

这是基于你上传的 `Watch8_ArgentinaFx_WearOS_Source.zip` 修改的 **独立安装新版**。核心汇率接口、7 种美元市场、ARS/USD/CNY/USDT 四币换算、Binance USDT、缓存、阿根廷时间、刷新规则和原版算法均保持不变，只调整手表界面和安装包 ID。

## 你指定的新页面

### 启动首页 — 无需上下滑动

- 第一行：`● 汇率通` / 小型 `↻ 更新汇率` 按钮
- 第二块：`输入币种：ARS ▾` / 点击金额打开数字键盘
- 下面三条紧凑的实时换算：美元 USD / 人民币 CNY / 泰达币 USDT（选择其他输入币种后自动换成另外三种）
- 最下方：`市场` / `USDT` / `详情` 三个入口，保留原来的全部功能
- 首屏和数字键盘均**没有纵向滚动容器**，按圆屏 dp 尺寸动态压缩字体和控件；长金额自动缩小字体显示

### 数字键盘 — 无需上下滑动

- 同一屏同时显示当前币种、输入金额、四排完整数字键（7–9 / 4–6 / 1–3 / 小数点、0、退格）、`AC 清零` 和 `✓ 完成`
- 按键立即刷新金额；按完成返回首页换算结果

7 种美元市场、Binance USDT 价差、汇率更新与来源详情及币种选择页仍然保留原页面的滚动能力，因为这些信息不能合理地全部压在一张圆屏上。

## 和旧版并存（避免安装失败）

新版安装包 ID 为 `com.exchange.watchfx.compact`，显示名称为 `汇率通·紧凑`。旧版安装包 ID 是 `com.exchange.watchfx`，因此**不会覆盖旧版或碰到旧版 debug 签名冲突**。新版首次启动不会继承旧版缓存和输入金额，但会重新加载汇率。

## GitHub Actions 编译

**方式 A：完整源码上传**：把本 ZIP 解压，把其中的所有文件/目录放到新仓库根目录（包括隐藏的 `.github/workflows/build-apk.yml`），推送到 main 分支后，Actions 自动构建。

**方式 B：仅两个文件上传**：GitHub 仓库根目录上传本项目的 ZIP 文件 `Watch8_FX_Compact_Source.zip`，另外在 `.github/workflows/build-apk.yml` 创建上传随包提供的同名 yml 文件（不可把 yml 仅放 ZIP 里，否则 GitHub 不会触发 Actions）。Workflow 自动解包并编译。

在 GitHub 仓库的 **Actions → Build Watch8 Compact FX APK** 中查看运行；成功后从 **Artifacts → Watch8-FX-Compact-APK** 下载 ZIP，解压后得到 `Watch8_FX_Compact-debug.apk`，用 Wear Installer 2 安装到手表。

项目编译配置：Java 17、Gradle 8.10.2、AGP 8.7.3、Android SDK 35、最低 Android 28 / Wear OS。编译前 Workflow 会运行原版的两个 Java 汇率算法测试。

## 验证说明

已通过：原版 `FxCalculatorTest`、`UsdtCalculatorTest` 单元测试；MainActivity Java 类型/语法检查（使用 Android API 轻量桩类）。当前运行环境缺少 Android SDK、Gradle 和手表模拟器，**因此尚未直接编译生成可安装的 APK，也未在实体 Galaxy Watch8 上验证无裁切**。GitHub Actions 构建成功并在实际手表检查后才能确认完整兼容。
